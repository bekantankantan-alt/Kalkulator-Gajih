# Kalkulator Gajih — GitHub APK Builder

1. Buat repository baru di GitHub.
2. Upload seluruh isi ZIP ini ke root repository, termasuk folder `.github`.
3. Buka tab **Actions**.
4. Pilih **Build APK - Kalkulator Gajih**, lalu tekan **Run workflow**.
5. Setelah build selesai, buka run tersebut dan unduh artifact **Kalkulator-Gajih-APK**.
6. Ekstrak artifact ZIP dan pasang `app-debug.apk` di Android.

Ikon PNG transparan disertakan sebagai launcher icon tanpa background tambahan dari proyek. Namun beberapa launcher Android tetap otomatis membingkai/memotong ikon mengikuti aturan ikon sistem. APK ini adalah debug build untuk uji coba.
